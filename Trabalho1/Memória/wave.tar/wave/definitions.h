
#define DT          0.005
#define DXYZ        50.0
#define HALF_LENGTH 8
